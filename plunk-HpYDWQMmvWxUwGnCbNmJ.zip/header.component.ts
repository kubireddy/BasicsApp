import {component} from '@angular/core';

@component({
  selector: 'header',
  templateUrl: './header.component.html'
})

export class HeaderCompoent implements OnInit {
  
  ngOnInit() {
    
  }
}
