
import {component, OnInit, OnDestroy } from '@angular/core'
import {Http, Response, OnDestroy } from '@angular/http'
import 'rxjs/Rx';
import 'subject/Observable'

@Component({
  selector: 'home',
  templateUrl: './home.component.html'
})

export class HomeCompoent implements OnInit. OnDestroy{
  
  myresponse;
  mySubscription: Subscription;
  
  constructor(private http: Http) {}
  
  ngOnInit() {
    this.mySubscription = this.makeCall().subscribe(
      (data) => {this.myresponse = data;},
      (error) => {this.myresponse = error;}
      );
  }
  
  
  makeCall() {
    return this.get('https://jsonplaceholder.typicode.com/photos')
            .map(
              (response: Response) => {
                return response.json();
              }
              )
            .catch(
              (error: Response) => {
                return Observable.throw(error);
              }
              )
              );
  }
  
  ngOnDestro() {
    this.mySubscription.unsubscribe();
  }
  
}

