
import {component, OnInit, OnDestroy, ActivatedRouter } from '@angular/core'
import {Http, Response, OnDestroy } from '@angular/http'
import 'rxjs/Rx';
import 'subject/Observable'




@component({
  selector: 'image',
  templateUrl: './image.component.html'
})

export class ImageCompoent implements OnInit {
  
  url: string
  
  constructor(private activated: ActivatedRouter) {}
  
  ngOnInit() {
    this.activated.queryParams.subscribe(
      (param: Params) => {
        this.url = param['url'];
      }
      );
  }
}