//our root app component
import {Component, NgModule, VERSION} from '@angular/core'
import {BrowserModule} from '@angular/platform-browser'
import {RouterModule} from '@angular/routes'
import {Homecomponent} from './home.component.ts'
import {Imagecomponent} from './Image.component.ts'
import {Headercomponent} from './header.component.ts'

const routes: Routes = [
  {path: '', redirectTo='home', pathMath='full'},
  {path: 'home', component: HomeComponent},
  {path: 'image', component: ImageComponent},
  ]




@Component({
  selector: 'my-app',
  templateurl: './app.component.ts',
})
export class App {
  name:string;
  constructor() {
    this.name = `Angular! v${VERSION.full}`
  }
}

@NgModule({
  imports: [ Homecomponent,
  Imagecomponent,
  Headercomponent,
  BrowserModule, RouterModule.forRoot(routes) ],
  declarations: [ App ],
  bootstrap: [ App ]
})
export class AppModule {}